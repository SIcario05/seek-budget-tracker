const express = require('express');
const router = express.Router();
const admin = require('firebase-admin');

// REGISTER user
router.post('/register', async (req, res) => {
  const { email, password } = req.body;
  try {
    const userRecord = await admin.auth().createUser({
      email,
      password,
    });
    res.status(201).send(`User ${userRecord.uid} created successfully`);
  } catch (error) {
    console.error(error);
    res.status(400).send(error.message);
  }
});

// LOGIN user (handled by frontend)
router.post('/login', async (req, res) => {
  res.send('Handle login on frontend using Firebase Auth SDK');
});

// FORGOT PASSWORD
router.post('/forgot-password', async (req, res) => {
  const { email } = req.body;
  try {
    const link = await admin.auth().generatePasswordResetLink(email);
    res.send(`Password reset link sent to ${email}: ${link}`);
  } catch (error) {
    console.error(error);
    res.status(400).send(error.message);
  }
});

module.exports = router;
