const express = require('express');
const router = express.Router();
const admin = require('firebase-admin'); 

module.exports = (db) => {
  const expenses = db.collection('expenses');

  // GET expenses by userId
  router.get('/:userId', async (req, res) => {
    const { userId } = req.params;
    console.log("Fetching expenses for userId:", userId);
    try {
      const snapshot = await expenses.where('userId', '==', userId).get();
      const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      res.json(data);
    } catch (err) {
      console.error('Error fetching expenses:', err);
      res.status(500).send(err.message);
    }
  });

  // POST new expense
  router.post('/', async (req, res) => {
    const { userId, title, amount, category, date } = req.body;
    console.log("Received POST body:", req.body);
    try {
      if (!userId || !title || !amount || !category || !date) {
        return res.status(400).send('Missing required fields');
      }
      const expense = {
        userId,
        title,
        amount,
        category,
        date: admin.firestore.Timestamp.fromDate(new Date(date)) // save as Timestamp
      };
      const result = await expenses.add(expense);
      console.log("Added expense ID:", result.id);
      res.status(201).json({ id: result.id, ...expense });
    } catch (err) {
      console.error('Error adding expense:', err);
      res.status(500).send(err.message);
    }
  });

  // DELETE expense
  router.delete('/:id', async (req, res) => {
    const { id } = req.params;
    try {
      await expenses.doc(id).delete();
      res.json({ message: 'Expense deleted' });
    } catch (err) {
      console.error('Error deleting expense:', err);
      res.status(500).send(err.message);
    }
  });

  return router;
};
