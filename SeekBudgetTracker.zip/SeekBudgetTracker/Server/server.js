const express = require('express');
const admin = require('firebase-admin');
const path = require('path');
const passport = require('passport');
const session = require('express-session');
const GoogleStrategy = require('passport-google-oauth20').Strategy;
const FacebookStrategy = require('passport-facebook').Strategy;

const authRoutes = require('./auth');

const app = express();
const PORT = 3000;

/* ===============================
   ✅ FIREBASE ADMIN INITIALIZE
================================= */
try {
  const serviceAccount = require("./serviceaccountkey.json");

  admin.initializeApp({
    credential: admin.credential.cert(serviceAccount),
    projectId: serviceAccount.project_id // Explicitly set project ID
  });

  console.log('✅ Firebase Admin initialized successfully');
} catch (error) {
  console.error('❌ Failed to initialize Firebase Admin:', error);
  process.exit(1);
}

const db = admin.firestore();


/* ===============================
   ✅ EXPRESS SESSION & PASSPORT
================================= */
app.use(session({
  secret: 'qwerty',
  resave: false,
  saveUninitialized: true
}));

app.use(passport.initialize());
app.use(passport.session());

passport.serializeUser((user, done) => done(null, user));
passport.deserializeUser((obj, done) => done(null, obj));

/* ===============================
   ✅ GOOGLE STRATEGY
================================= */
passport.use(new GoogleStrategy({
  clientID: '847950327796-52vk4blu9havesbp75ju2p9r57nhq2pr.apps.googleusercontent.com',
  clientSecret: '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',
  callbackURL: '/auth/google/callback'
},
(accessToken, refreshToken, profile, done) => {
  return done(null, profile);
}));

/* ===============================
   ✅ FACEBOOK STRATEGY
================================= */
passport.use(new FacebookStrategy({
  clientID: 'YOUR_FACEBOOK_APP_ID',
  clientSecret: 'YOUR_FACEBOOK_APP_SECRET',
  callbackURL: '/auth/facebook/callback'
},
(accessToken, refreshToken, profile, done) => {
  return done(null, profile);
}));

/* ===============================
   ✅ MIDDLEWARES
================================= */
app.use(express.static(path.join(__dirname, '../Dash')));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

/* ===============================
   ✅ ROUTES
================================= */

// root login page
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, '../Dash/login.html'));
});

// google auth
app.get('/auth/google',
  passport.authenticate('google', { scope: ['profile', 'email'] })
);

app.get('/auth/google/callback',
  passport.authenticate('google', { failureRedirect: '/login.html' }),
  (req, res) => {
    res.redirect('/dash.html');
  }
);

// facebook auth
app.get('/auth/facebook',
  passport.authenticate('facebook')
);

app.get('/auth/facebook/callback',
  passport.authenticate('facebook', { failureRedirect: '/login.html' }),
  (req, res) => {
    res.redirect('/dash.html');
  }
);

// auth routes
app.use('/', authRoutes);

/* ===============================
   ✅ CRUD EXPENSE ROUTES
================================= */
// create expense
app.post('/expenses', async (req, res) => {
  const { userId, title, amount, category, date } = req.body;
  console.log("POST /expenses", req.body);

  // Validation
  if (!userId) return res.status(400).send("Missing userId");
  if (!title) return res.status(400).send("Missing title");
  if (!amount) return res.status(400).send("Missing amount");
  if (!category) return res.status(400).send("Missing category");
  if (!date) return res.status(400).send("Missing date");

  try {
    const expenseData = {
      userId,
      title,
      amount: parseFloat(amount),
      category,
      date: admin.firestore.Timestamp.fromDate(new Date(date)),
      createdAt: admin.firestore.FieldValue.serverTimestamp()
    };

    const docRef = await db.collection('expenses').add(expenseData);
    console.log(`✅ Expense added with ID: ${docRef.id}`);
    
    res.status(201).json({
      id: docRef.id,
      message: `Expense added successfully`
    });
  } catch (error) {
    console.error('❌ Error adding expense:', error);
    res.status(500).json({
      error: 'Failed to add expense',
      details: error.message
    });
  }
});

// read expenses for a user
app.get('/expenses/:userId', async (req, res) => {
  const { userId } = req.params;
  console.log(`GET /expenses/${userId}`);
  
  try {
    if (!userId) return res.status(400).send('Missing userId');
    
    const snapshot = await db.collection('expenses')
      .where('userId', '==', userId)
      .orderBy('createdAt', 'desc')
      .get();
    
    const expenses = snapshot.docs.map(doc => ({ 
      id: doc.id, 
      ...doc.data() 
    }));
    
    console.log(`✅ Found ${expenses.length} expenses for user ${userId}`);
    res.json(expenses);
  } catch (error) {
    console.error('❌ Error fetching expenses:', error);
    res.status(500).json({
      error: 'Failed to fetch expenses',
      details: error.message
    });
  }
});

// update expense
app.put('/expenses/:id', async (req, res) => {
  const { id } = req.params;
  const { title, amount, category, date } = req.body;
  console.log(`PUT /expenses/${id}`, req.body);
  
  try {
    const updateData = {
      title,
      amount: parseFloat(amount),
      category,
      date: admin.firestore.Timestamp.fromDate(new Date(date)),
      updatedAt: admin.firestore.FieldValue.serverTimestamp()
    };

    await db.collection('expenses').doc(id).update(updateData);
    console.log(`✅ Expense ${id} updated`);
    res.json({ message: 'Expense updated successfully' });
  } catch (error) {
    console.error('❌ Error updating expense:', error);
    res.status(500).json({
      error: 'Failed to update expense',
      details: error.message
    });
  }
});

// delete expense
app.delete('/expenses/:id', async (req, res) => {
  const { id } = req.params;
  console.log(`DELETE /expenses/${id}`);
  
  try {
    await db.collection('expenses').doc(id).delete();
    console.log(`✅ Expense ${id} deleted`);
    res.json({ message: 'Expense deleted successfully' });
  } catch (error) {
    console.error('❌ Error deleting expense:', error);
    res.status(500).json({
      error: 'Failed to delete expense',
      details: error.message
    });
  }
});

/* ===============================
   ✅ PROFILE ROUTES
================================= */

// get profile
app.get('/profile/:userId', async (req, res) => {
  const { userId } = req.params;
  try {
    if (!userId) return res.status(400).send("Missing userId");
    const doc = await db.collection('profiles').doc(userId).get();
    if (!doc.exists) return res.status(404).send('Profile not found');
    res.json(doc.data());
  } catch (error) {
    console.error('❌ Error fetching profile:', error);
    res.status(500).json({
      error: 'Failed to fetch profile',
      details: error.message
    });
  }
});

// update profile
app.post('/profile', async (req, res) => {
  const { userId, name, bio, goals } = req.body;
  if (!userId) return res.status(400).send("Missing userId");
  try {
    const profileData = {
      name,
      bio,
      goals,
      updatedAt: admin.firestore.FieldValue.serverTimestamp()
    };
    await db.collection('profiles').doc(userId).set(profileData, { merge: true });
    console.log(`✅ Profile saved for user ${userId}`);
    res.json({ message: "Profile saved successfully" });
  } catch (error) {
    console.error('❌ Error saving profile:', error);
    res.status(500).json({
      error: "Failed to save profile",
      details: error.message
    });
  }
});


/* ===============================
   ✅ AI SUGGESTIONS ROUTE
================================= */
app.post('/api/ai-suggestions', async (req, res) => {
  const prompt = req.body.prompt;

  if (!prompt) {
    return res.status(400).json({ error: "Missing prompt" });
  }

  try {
    const response = await fetch("https://openrouter.ai/api/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": "Bearer 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"
      },
      body: JSON.stringify({
        model: "qwen/qwen3-235b-a22b-07-25:free",
        messages: [
          { role: "system", content: "You are a budgeting assistant. Give super short and simple tips only." },
          { role: "user", content: prompt }
        ]
      })
    });

    const data = await response.json();

    // log full json and final content clearly
    console.log("✅ OpenRouter AI response full:", JSON.stringify(data, null, 2));

    const aiContent = data.choices?.[0]?.message?.content || "No AI response.";

    console.log("✅ AI final content:", aiContent);

    res.json({ aiResponse: aiContent });

  } catch (error) {
    console.error('❌ OpenRouter AI error:', error);
    res.status(500).json({ error: 'AI request failed', details: error.message });
  }
});


/* ===============================
   ✅ START SERVER
================================= */
app.listen(PORT, () => {
  console.log(`🚀 Budget Tracker Server running at http://localhost:${PORT}`);
});